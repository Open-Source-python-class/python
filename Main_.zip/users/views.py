from django.shortcuts import render, redirect
from websites import templates
from .models import User
# Create your views here.
def login(request) :
    if request.method == "POST" :
        users = User.objects.all()
        ID = request.POST.get('ID')
        password = request.POST.get('password')
        for item in users :
            if item.User_id == ID :
                user = User.objects.get(User_id=ID)
                if user.pw == password :
                    login = int(1)
                    logout = int(1)
                    item.status = login
                    item.save()
                    return render(request, 'main.html', {'login':login, 'logout':logout})
                else :
                    error = int(1)
                    return render(request, 'login.html', {'error1':error})
        error = int(1)
        return render(request, 'login.html', {'error1':error})
    return render(request, 'login.html')

def login1(request) :
    if request.method == "POST" :
        users = User.objects.all()
        ID = request.POST.get('ID')
        password = request.POST.get('password')
        for item in users :
            if item.User_id == ID :
                user = User.objects.get(User_id=ID)
                if user.pw == password :
                    login = int(1)
                    logout = int(1)
                    item.status = login
                    item.save()
                    return render(request, 'main.html', {'login':login, 'logout':logout})
                else :
                    error = int(1)
                    return render(request, 'signup.html', {'error1':error})
        error = int(1)
        return render(request, 'signup.html', {'error1':error})
    return render(request, 'signup.html')


def signup(request) :
    if request.method == "POST" :
        ID = request.POST.get('ID')
        password = request.POST.get('password')
        password_again = request.POST.get('password_again')
        name = request.POST.get('name')
        identification_number = request.POST.get('identification_number')
        users = User.objects.all()
        for item in users :
            if item.User_id == ID :
                error = int(2)
                return render(request, 'signup.html', {'error':error})
        if password_again != password :
            error = int(1)
            return render(request, 'signup.html', {'error':error})
        elif len(request.POST.get('name')) == 0 :
            error = 3
            return render(request,'signup.html', {'error':error})
        elif len(request.POST.get('identification_number')) != 6 :
            error = 4
            return render(request, 'signup.html',{'error':error})

        user = User(name=name, pw=password, User_id=ID, identification_number = identification_number)
        user.save()
        return redirect('login')
    return render(request, 'signup.html')


def logout(request) :
    user = User.objects.all()
    for item in user :
        if item.status == 1 :
            item.status = 0
            item.save()
            login = 0
            return render(request, 'main.html', {'login':login})


def find_id(request) :
    if request.method == "POST" :
        identification_number = int(request.POST.get('identification_number'))
        users = User.objects.all()
        for user in users : 
            if user.identification_number == identification_number :
                user1 = User.objects.get(identification_number = identification_number)
                ID = user1.User_id
                return render(request, 'correct.html', {'id':ID})
        error = int(1)
        return render(request, 'find_id.html', {'error':error})
    return render(request, 'find_id.html')


def find_pw(request) :
    if request.method == "POST" :
        ID = request.POST.get('ID')
        identification_number = int(request.POST.get('identification_number'))
        user = User.objects.all()
        for item in user :
            if item.User_id == ID :
                if item.identification_number == identification_number :
                    user1 = User.objects.get(User_id=ID)
                    pw = user1.pw
                    return render(request, 'correct2.html', {'pw':pw})
        error = 1
        return render(request, 'find_pw.html', {'error':error})
    return render(request, 'find_pw.html')

