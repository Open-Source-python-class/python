from django.urls import path
from . import views
urlpatterns = [
    path('login/', views.login, name="login"),
    path('signup/', views.signup, name="signup"),
    path('logout/', views.logout, name="logout"),
    path('find_id/', views.find_id, name = "find_id"),
    path('find_pw/', views.find_pw, name="find_pw"),
    path('ts/', views.ts, name="ts"),
]