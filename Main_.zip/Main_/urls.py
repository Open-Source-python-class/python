from django.contrib import admin
from django.urls import path, include
from websites import views , urls
from users import urls as users_urls

urlpatterns = [
    path('admin/', admin.site.urls), 
    path('', views.main, name="main"),
    path('websites/', include(urls)),
    path('users/', include(users_urls)),
]
