from django.shortcuts import render
from users.models import User
# Create your views here.
def main(request):
    user = User.objects.all()
    for item in user :
        if item.status == 1 :
            login = 1
            return render(request, 'main.html', {'login':login})
    login = 0
    return render(request, 'main.html',{'login':login})


def bottom(request) :
    return render(request,'bottom.html')


def login(request) :
    return render(request,'login.html')


def men(request) :
    return render(request,'men.html')


def outer(request) :
    return render(request,'outer.html')


def signup(request) :
    return render(request,'signup.html')


def top(request) :
    return render(request,'top.html')


def women(request) :
    return render(request,'women.html')