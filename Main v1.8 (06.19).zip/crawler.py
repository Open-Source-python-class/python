import requests
import urllib.request
from bs4 import BeautifulSoup
import json
import os
import re
## Python이 실행될 때 DJANGO_SETTINGS_MODULE이라는 환경 변수에 현재 프로젝트의 settings.py파일 경로를 등록합니다.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "Main.settings")
## 이제 장고를 가져와 장고 프로젝트를 사용할 수 있도록 환경을 만듭니다.
import django
django.setup()
import random

from products.models import Product

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# 남자 아우터 정장      https://store.musinsa.com/app/items/lists/002003/?category=&d_cat_cd=002003&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 남자 아우터 패딩      https://store.musinsa.com/app/items/lists/002016/?category=&d_cat_cd=002016&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 남자 아우터 코트      https://store.musinsa.com/app/items/lists/002007/?category=&d_cat_cd=002007&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 남자 상의 후드티      https://store.musinsa.com/app/items/lists/002022/?category=&d_cat_cd=002022&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 남자 상의 반팔        https://store.musinsa.com/app/items/lists/001001/?category=&d_cat_cd=001001&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 남자 상의 긴팔        https://store.musinsa.com/app/items/lists/001010/?category=&d_cat_cd=001010&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 남자 하의 반바지      https://store.musinsa.com/app/items/lists/003009/?category=&d_cat_cd=003009&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 남자 하의 청바지      https://store.musinsa.com/app/items/lists/003002/?category=&d_cat_cd=003002&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 남자 하의 정장바지    https://store.musinsa.com/app/items/lists/003008/?category=&d_cat_cd=003008&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=2&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=

# 여자 하의 정장바지    https://store.musinsa.com/app/items/lists/003008/?category=&d_cat_cd=003008&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 여자 하의 청바지      https://store.musinsa.com/app/items/lists/003002/?category=&d_cat_cd=003002&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 여자 하의 반바지      https://store.musinsa.com/app/items/lists/003009/?category=&d_cat_cd=003009&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 여자 상의 후드티      https://store.musinsa.com/app/items/lists/001004/?category=&d_cat_cd=001004&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 여자 상의 반팔        https://store.musinsa.com/app/items/lists/001001/?category=&d_cat_cd=001001&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 여자 상의 긴팔        https://store.musinsa.com/app/items/lists/001010/?category=&d_cat_cd=001010&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 여자 아우터 코트      https://store.musinsa.com/app/items/lists/002007/?category=&d_cat_cd=002007&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 여자 아우터 패딩      https://store.musinsa.com/app/items/lists/002016/?category=&d_cat_cd=002016&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=
# 여자 아우터 정장      https://store.musinsa.com/app/items/lists/002003/?category=&d_cat_cd=002003&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=

def parse_crawl():
    r = requests.get('https://store.musinsa.com/app/items/lists/002003/?category=&d_cat_cd=002003&u_cat_cd=&brand=&sort=pop&sub_sort=&display_cnt=90&page=1&page_kind=category&list_kind=small&free_dlv=&ex_soldout=&sale_goods=&exclusive_yn=&price=&color=&a_cat_cd=&sex=4&size=&tag=&popup=&brand_favorite_yn=&goods_favorite_yn=&blf_yn=&campaign_yn=&price1=&price2=')
    html = r.content
    soup = BeautifulSoup(html, 'html.parser')

    title_html = soup.select('.li_inner')

    result = []
    
    

    for title in title_html:
        nprice = str(title.find_all("span", class_="txt_price_member"))
        nprice = re.sub('<.+?>', '', nprice, 0).strip()
        nprice1 = re.sub('&nbsp; | &nbsp;| \n|\t|\r', '', nprice, 0).strip()
        nprice2 = re.sub('\n\n', '', nprice1)

        nbrand = str(title.find_all("p", class_="item_title"))
        nbrand = re.sub('<.+?>', '', nbrand, 0).strip()
        nbrand = re.sub('&nbsp; | &nbsp;| \n|\t|\r', '', nbrand, 0).strip()
        nbrand = re.sub('\n\n', '', nbrand, 0).strip()

        ndescription = str(title.find_all("p", class_="list_info"))
        ndescription = re.sub('<.+?>', '', ndescription, 0).strip()
        ndescription = re.sub('&nbsp; | &nbsp;| \n|\t|\r', '', ndescription, 0).strip()
        ndescription = re.sub('\n\n', '', ndescription, 0).strip()
        ndescription = re.sub('\n', '', ndescription, 0).strip()

        nimageURL = title.find("img")['data-original']
      
        nitem_num = random.randint(1, 50)

        ncategory1 = "여자"
        ncategory2 = "아우터"
        ncategory3 = "정장"

        print(nimageURL)

        data={
            'price' : nprice2,
            'brand' : nbrand,
            'description' : ndescription,
            'imageURL' : nimageURL,
            'item_num' : nitem_num,
            'category1' : ncategory1,
            'category2' : ncategory2,
            'category3' : ncategory3,
        }
        result.append(data)

    return result

    # 0 번지에 title price description images
    #          @@     @@@    @@@@      @@@
    #         쥰내   어렵구  살려주시고   으아악



## 이 명령어는 이 파일이 import가 아닌 python에서 직접 실행할 경우에만 아래 코드가 동작하도록 합니다.
if __name__=='__main__':
    data_dict = parse_crawl()
    for i in data_dict :
        Product(
            price=str(i['price']).replace('[', '').replace(']',''), 
            brand=str(i['brand']).replace('[', '').replace(']',''), 
            description=str(i['description']).replace('[', '').replace(']',''), 
            imageURL=i['imageURL'],
            item_num=i['item_num'],
            category1=i['category1'],
            category2=i['category2'],
            category3=i['category3'],
        ).save()