"""Main URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from websites import urls, views
from django.conf import settings
from django.conf.urls.static import static
from users import urls as users_urls

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.main, name='main'),
    path('users/', include(users_urls)),
    path('men/', views.men, name='men'),
    path('women/', views.women, name='women'),
    path('All_Outer/', views.All_Outer, name='All_Outer'),
    path('All_Bottom/', views.All_Bottom, name='All_Bottom'),
    path('All_Top/', views.All_Top, name='All_Top'),
    path('All_Product/', views.All_Product, name='All_Product'),
    path('M_Bottom/', views.M_Bottom, name='M_Bottom'),
    path('M_Outer/', views.M_Outer, name='M_Outer'),
    path('M_Top/', views.M_Top, name='M_Top'),
    path('W_Bottom/', views.W_Bottom, name='W_Bottom'),
    path('W_Outer/', views.W_Outer, name='W_Outer'),
    path('W_Top/', views.W_Top, name='W_Top'),
    path('Buy/<int:id>', views.Buy, name='Buy'),
    path('Payment/<int:id>', views.Payment, name="Payment"),
    path('<int:id>', views.Payment2, name="Payment2"),
    path('search/', views.search, name="search"),
    path('app_sellout/', views.app_sellout, name="app_sellout"),
    path('M_suit/', views.M_suit, name='M_suit'),
    path('M_coat/', views.M_coat, name='M_coat'),
    path('M_padding/', views.M_padding, name='M_padding'),
    path('M_shortshirts/', views.M_shortshirts, name='M_shortshirts'),
    path('M_longshirts/', views.M_longshirts, name='M_longshirts'),
    path('M_hoodshirts/', views.M_hoodshirts, name='M_hoodshirts'),
    path('M_shortpants/', views.M_shortpants, name='M_shortpants'),
    path('M_jeans/', views.M_jeans, name='M_jeans'),
    path('M_suitpants/', views.M_suitpants, name='M_suitpants'),

    path('W_suit/', views.W_suit, name='W_suit'),
    path('W_coat/', views.W_coat, name='W_coat'),
    path('W_padding/', views.W_padding, name='W_padding'),
    path('W_shortshirts/', views.W_shortshirts, name='W_shortshirts'),
    path('W_longshirts/', views.W_longshirts, name='W_longshirts'),
    path('W_hoodshirts/', views.W_hoodshirts, name='W_hoodshirts'),
    path('W_shortpants/', views.W_shortpants, name='W_shortpants'),
    path('W_jeans/', views.W_jeans, name='W_jeans'),
    path('W_suitpants/', views.W_suitpants, name='W_suitpants'),
    # id라는 이름으로, integer의 타입으로 주소 값을 전달할 것임.
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
