from django.shortcuts import render
from products.models import Product
from users.models import User
from users.models import User_Info
# Create your views here.

def main(request):
    login = Check_user()
    return render(request, 'main.html', {'login':login})

def login(request):
    return render(request, "login.html")

def signup(request):
    return render(request, "signup.html")

def men(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    men = []
    for i in products :
        if(i.category1 == "남자") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               men.append(i)
    return render(request, "men.html", {'products' : men, 'login':login})

def women(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    women = []
    for i in products :
        if(i.category1 == "여자") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               women.append(i)
    return render(request, "women.html", {'products' : women, 'login':login})

def All_Bottom(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    bottom = []
    for i in products :
        if(i.category2 == "하의") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               bottom.append(i)
    return render(request, 'All.html', {'products' : bottom, 'login':login})

def All_Outer(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    outer = []
    for i in products :
        if(i.category2 == "아우터") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               outer.append(i)
    return render(request, 'All.html', {'products' : outer, 'login':login})

def All_Product(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    product = []
    for i in products :
        preplace=i.price.replace(",","")
        preplace=preplace.replace("원","")
        if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
           product.append(i)
    return render(request, 'All.html', {'products' : product, 'login':login})

def All_Top(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    top = []
    for i in products :
        if(i.category2 == "상의") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               top.append(i)
    return render(request, 'All.html', {'products' : top, 'login':login})

def M_Bottom(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    M_bottom = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "하의") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   M_bottom.append(i)

    return render(request, 'men.html', {'products' : M_bottom, 'login':login})

def M_Outer(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    M_outer = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "아우터") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   M_outer.append(i)

    return render(request, 'men.html', {'products' : M_outer, 'login':login})

def M_Top(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    M_top = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "상의") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   M_top.append(i)

    return render(request, 'men.html', {'products' : M_top, 'login':login})

# 상품의 고유번호 id
def Buy(request, id):
    product = Product.objects.get(pk=id)
    login = Check_user()

    return render(request, 'Buy.html', {'product' : product, 'login':login})

def W_Bottom(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    W_bottom = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "하의") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   W_bottom.append(i)

    return render(request, 'women.html', {'products' : W_bottom, 'login':login})

def W_Outer(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    W_outer = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "아우터") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   W_outer.append(i)

    return render(request, 'women.html', {'products' : W_outer, 'login':login})

def W_Top(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    W_top = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "상의") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   W_top.append(i)

    return render(request, 'women.html', {'products' : W_top, 'login':login})

def Payment(request, id):
    product = Product.objects.get(pk=id)
    buy_num = request.GET.get("buy_num")
    login = Check_user()

    if login == 0 :
        error = int(4)
        return render(request, 'Buy.html', {'product' : product, 'status' : error, 'login':login})

    if product.item_num <= 0 :
        error = int(2)
        return render(request, 'Buy.html', {'product' : product, 'status' : error, 'login':login})
    if (product.item_num - int(buy_num)) < 0 :
        error = int(1)
        return render(request, 'Buy.html', {'product' : product, 'status' : error, 'login':login})
    if int(buy_num) < 0 :
        error = int(3)
        return render(request, 'Buy.html', {'product' : product, 'status' : error, 'login':login})
    product.item_num = product.item_num - int(buy_num)
    product.save()

    preplace=product.price.replace(",","")
    preplace=preplace.replace("원","")
    price = int(buy_num) * int(preplace)
    return render(request, 'Payment.html', {'product' : product, 'login':login, 'buy_num':buy_num, 'price':price})

def Payment2(request, id):
    product = Product.objects.get(pk=id)
    user = User.objects.all()
    login = Check_user()

    for item in user:
        if item.status == 1:
            user = item
            break

    if request.method == "POST" :
        delivery_location = request.POST.get("delivery_location")
        name = user.name
        recipient = request.POST.get("recipient")
        phone_number = request.POST.get("phone_number")
        payment_method = request.POST.get("payment_method")
        bank_name = request.POST.get("bank_name")
        bank_owner = request.POST.get("bank_owner")
        card_number = request.POST.get("card_number")
        product_name = product.description

    user_info = User_Info(
        name=name, 
        delivery_location=delivery_location, 
        recipient=recipient, 
        phone_number=phone_number,
        payment_method=payment_method,
        bank_name=bank_name,
        bank_owner=bank_owner,
        card_number=card_number,
        product_name=product_name,
    )
    user_info.save()
    return render(request, 'main.html', {'login':login})

def search(request):
    login = Check_user()
    products = Product.objects.all()
    sdata = request.GET.get('sdata','')
    gender = request.GET.get('gender','')
    clothes_type = request.GET.get('clothes_type','')


    if (sdata==''):
        sdata ='default'

    search = []
    if sdata == 'default':
        if gender == '전체' :
            if clothes_type == '전체':
                for i in products :
                    search.append(i)
            elif clothes_type == '아우터':
                for i in products :
                    if i.category2 == "아우터" :
                        search.append(i)
            elif clothes_type == '상의':
                for i in products :
                    if i.category2 == "상의" :
                        search.append(i)
            elif clothes_type == '하의':
                for i in products :
                    if i.category2 == "하의" :
                        search.append(i)

        elif gender == '남자' :            
            if clothes_type == '전체':
                for i in products :
                    if i.category1 == '남자':
                        search.append(i)
            elif clothes_type == '아우터':
                for i in products :
                    if i.category2 == "아우터" and i.category1 == '남자':
                        search.append(i)
            elif clothes_type == '상의':
                for i in products :
                    if i.category2 == "상의" and i.category1 == '남자' :
                        search.append(i)
            elif clothes_type == '하의':
                for i in products :
                    if i.category2 == "하의" and i.category1 == '남자' :
                        search.append(i)

        elif gender == '여자' :            
            if clothes_type == '전체':
                for i in products :
                    if i.category1 == '여자':
                     search.append(i)
            elif clothes_type == '아우터':
                for i in products :
                    if i.category2 == "아우터" and i.category1 == '여자':
                        search.append(i)
            elif clothes_type == '상의':
                for i in products :
                    if i.category2 == "상의" and i.category1 == '여자':
                        search.append(i)
            elif clothes_type == '하의':
                for i in products :
                    if i.category2 == "하의" and i.category1 == '여자':
                        search.append(i)    
    
    else:
        if gender == '전체' :
            if clothes_type == '전체':
                for i in products :
                    if sdata == i.brand :
                        search.append(i)
                    elif sdata == i.category3 :
                        search.append(i)
            elif clothes_type == '아우터':
                for i in products :
                    if i.Category2 == "아우터" :
                        if sdata == i.brand :
                            search.append(i)
                        elif sdata == i.category3:
                            search.append(i)
            elif clothes_type == '상의':
                for i in products :
                    if i.category2 == "상의" :
                        if sdata == i.brand :
                            search.append(i)
                        elif sdata == i.category3:
                           search.append(i)
            elif clothes_type == '하의':
                for i in products :
                    if i.category2 == "하의" :
                        if sdata == i.brand :
                            search.append(i)
                        elif sdata == i.category3:
                            search.append(i)

        elif gender == '남자' :
                if clothes_type == '전체':
                    for i in products :
                        if i.category1 == '남자' : 
                            if sdata == i.brand :
                                search.append(i)
                            elif sdata == i.category3 :
                                search.append(i)
                elif clothes_type == '아우터':
                    for i in products :
                        if i.category2 == "아우터" and i.category1 == '남자' :
                            if sdata == i.brand :
                                search.append(i)
                            elif sdata == i.category3:
                                search.append(i)
                elif clothes_type == '상의':
                    for i in products :
                        if i.category2 == "상의" and i.category1 == '남자' :
                            if sdata == i.brand :
                                search.append(i)
                            elif sdata == i.category3:
                                search.append(i)
                elif clothes_type == '하의':
                    for i in products :
                        if i.category2 == "하의" and i.category1 == '남자' :
                            if sdata == i.brand :
                                search.append(i)
                            elif sdata == i.category3:
                                search.append(i)

        elif gender == '여자' :
                if clothes_type == '전체':
                    for i in products :
                        if i.category1 == '여자':
                            if sdata == i.brand :
                                search.append(i)
                            elif sdata == i.category3 :
                                search.append(i)
                elif clothes_type == '아우터':
                    for i in products :
                        if i.category2 == "아우터" and i.category1 == '여자':
                            if sdata == i.brand :
                                search.append(i)
                            elif sdata == i.category3:
                                search.append(i)
                elif clothes_type == '상의':
                    for i in products :
                        if i.category2 == "상의" and i.category1 == '여자':
                            if sdata == i.brand :
                                search.append(i)
                            elif sdata == i.category3:
                                search.append(i)
                elif clothes_type == '하의':
                    for i in products :
                        if i.category2 == "하의" and i.category1 == '여자':
                            if sdata == i.brand :
                                search.append(i)
                            elif sdata == i.category3:
                                search.append(i)        

    return render(request, 'search.html', {'products':search, 'login':login})

def Check_user():
    user = User.objects.all()
    for item in user :
        if item.status == 1 :
            return 1 
    return 0

def app_sellout(request):
    products = Product.objects.all()
    login = Check_user()
    psellout = []
    for i in products :
        if (i.item_num < 10) :
            psellout.append(i)

    return render(request, 'app_sellout.html', {'products' : psellout, 'login':login})

def M_suit(request):
    login = Check_user()
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_suit = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "아우터") :
                if(i.category3 == "정장"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_suit.append(i)
    return render(request, 'men.html', {'products' : M_suit, 'login':login})

def M_coat(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_coat = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "아우터") :
                if(i.category3 == "코트"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_coat.append(i)
    return render(request, 'men.html', {'products' : M_coat, 'login':login})

def M_padding(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_padding = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "아우터") :
                if(i.category3 == "패딩"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_padding.append(i)
    return render(request, 'men.html', {'products' : M_padding, 'login':login})

def M_shortshirts(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_shortshirts = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "상의") :
                if(i.category3 == "반팔"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_shortshirts.append(i)
    return render(request, 'men.html', {'products' : M_shortshirts, 'login':login})

def M_longshirts(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_longshirts = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "상의") :
                if(i.category3 == "긴팔"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_longshirts.append(i)
    return render(request, 'men.html', {'products' : M_longshirts, 'login':login})

def M_hoodshirts(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_hoodshirts = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "상의") :
                if(i.category3 == "후드티"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_hoodshirts.append(i)
    return render(request, 'men.html', {'products' : M_hoodshirts, 'login':login})

def M_shortpants(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_shortpants = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "하의") :
                if(i.category3 == "반바지"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_shortpants.append(i)
    return render(request, 'men.html', {'products' : M_shortpants, 'login':login})

def M_jeans(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_jeans = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "하의") :
                if(i.category3 == "청바지"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_jeans.append(i)
    return render(request, 'men.html', {'products' : M_jeans, 'login':login})

def M_suitpants(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    M_suitpants = []
    for i in products :
        if(i.category1 == "남자") :
            if(i.category2 == "하의") :
                if(i.category3 == "정장바지"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        M_suitpants.append(i)
    return render(request, 'men.html', {'products' : M_suitpants, 'login':login})

def W_suit(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_suit = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "아우터") :
                if(i.category3 == "정장"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_suit.append(i)
    return render(request, 'women.html', {'products' : W_suit, 'login':login})

def W_coat(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_coat = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "아우터") :
                if(i.category3 == "코트"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_coat.append(i)
    return render(request, 'women.html', {'products' : W_coat, 'login':login})

def W_padding(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_padding = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "아우터") :
                if(i.category3 == "패딩"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_padding.append(i)
    return render(request, 'women.html', {'products' : W_padding, 'login':login})

def W_shortshirts(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_shortshirts = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "상의") :
                if(i.category3 == "반팔"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_shortshirts.append(i)
    return render(request, 'women.html', {'products' : W_shortshirts, 'login':login})

def W_longshirts(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_longshirts = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "상의") :
                if(i.category3 == "긴팔"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_longshirts.append(i)
    return render(request, 'women.html', {'products' : W_longshirts, 'login':login})

def W_hoodshirts(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_hoodshirts = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "상의") :
                if(i.category3 == "후드티"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_hoodshirts.append(i)
    return render(request, 'women.html', {'products' : W_hoodshirts, 'login':login})

def W_shortpants(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_shortpants = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "하의") :
                if(i.category3 == "반바지"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_shortpants.append(i)
    return render(request, 'women.html', {'products' : W_shortpants, 'login':login})

def W_jeans(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_jeans = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "하의") :
                if(i.category3 == "청바지"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_jeans.append(i)
    return render(request, 'women.html', {'products' : W_jeans, 'login':login})

def W_suitpants(request):
    products = Product.objects.all()
    price1 = request.GET.get('price1','')
    login = Check_user()
    if(price1==''):
        price1='0'
    price2 = request.GET.get('price2','')
    if(price2==''):
        price2='1000000'

    W_suitpants = []
    for i in products :
        if(i.category1 == "여자") :
            if(i.category2 == "하의") :
                if(i.category3 == "정장바지"):
                    preplace=i.price.replace(",","")
                    preplace=preplace.replace("원","")
                    if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                        W_suitpants.append(i)
    return render(request, 'women.html', {'products' : W_suitpants, 'login':login})