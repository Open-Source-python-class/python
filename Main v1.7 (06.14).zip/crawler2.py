import requests
import urllib.request
from bs4 import BeautifulSoup
import json
import os
import re
## Python이 실행될 때 DJANGO_SETTINGS_MODULE이라는 환경 변수에 현재 프로젝트의 settings.py파일 경로를 등록합니다.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "Main.settings")
## 이제 장고를 가져와 장고 프로젝트를 사용할 수 있도록 환경을 만듭니다.
import django
django.setup()
import random

from products.models import Product

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# 남자 아우터 블레이저  https://store.musinsa.com/app/items/lists/002003
# 남자 상의 반팔        https://store.musinsa.com/app/items/lists/001001    
# 남자 상의 긴팔        https://store.musinsa.com/app/items/lists/001010
# 남자 상의 셔츠        https://store.musinsa.com/app/items/lists/001002
# 남자 하의 조거팬츠    https://store.musinsa.com/app/items/lists/003004/?tag=%EC%A1%B0%EA%B1%B0%ED%8C%AC%EC%B8%A0
# 여자는 종목만 정해주세욥

def parse_crawl():
    r = requests.get('https://store.musinsa.com/app/items/lists/003004/?tag=%EC%A1%B0%EA%B1%B0%ED%8C%AC%EC%B8%A0')

    html = r.content
    soup = BeautifulSoup(html, 'html.parser')

    title_html = soup.select('.li_inner')

    result = []
    
    
    
    for title in title_html:
        nprice = str(title.find_all("span", class_="txt_price_member"))
        nprice = re.sub('<.+?>', '', nprice, 0).strip()
        nprice1 = re.sub('&nbsp; | &nbsp;| \n|\t|\r', '', nprice, 0).strip()
        nprice2 = re.sub('\n\n', '', nprice1)

        nbrand = str(title.find_all("p", class_="item_title"))
        nbrand = re.sub('<.+?>', '', nbrand, 0).strip()
        nbrand = re.sub('&nbsp; | &nbsp;| \n|\t|\r', '', nbrand, 0).strip()
        nbrand = re.sub('\n\n', '', nbrand, 0).strip()

        ndescription = str(title.find_all("p", class_="list_info"))
        ndescription = re.sub('<.+?>', '', ndescription, 0).strip()
        ndescription = re.sub('&nbsp; | &nbsp;| \n|\t|\r', '', ndescription, 0).strip()
        ndescription = re.sub('\n\n', '', ndescription, 0).strip()
        ndescription = re.sub('\n', '', ndescription, 0).strip()

        nimageURL = title.find("img")['data-original']
      
        nitem_num = random.randint(1, 50)

        ncategory1 = "men"
        ncategory2 = "bottom"
        ncategory3 = "jogger-pants"

        print(nimageURL)

        data={
            'price' : nprice2,
            'brand' : nbrand,
            'description' : ndescription,
            'imageURL' : nimageURL,
            'item_num' : nitem_num,
            'category1' : ncategory1,
            'category2' : ncategory2,
            'category3' : ncategory3,
        }
        result.append(data)

    return result

    # 0 번지에 title price description images
    #          @@     @@@    @@@@      @@@
    #         쥰내   어렵구  살려주시고   으아악



## 이 명령어는 이 파일이 import가 아닌 python에서 직접 실행할 경우에만 아래 코드가 동작하도록 합니다.
if __name__=='__main__':
    data_dict = parse_crawl()
    for i in data_dict :
        Product(
            price=str(i['price']).replace('[', '').replace(']',''), 
            brand=str(i['brand']).replace('[', '').replace(']',''), 
            description=str(i['description']).replace('[', '').replace(']',''), 
            imageURL=i['imageURL'],
            item_num=i['item_num'],
            category1=i['category1'],
            category2=i['category2'],
            category3=i['category3'],
        ).save()