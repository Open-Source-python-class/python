from django.shortcuts import render
from django.db.models import F
from products.models import Product
from users.models import User
# Create your views here.

def main(request):
    login = Check_user()
    return render(request, 'main.html', {'login':login})

def login(request):
    return render(request, "login.html")

def signup(request):
    return render(request, "signup.html")

def men(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    men = []
    for i in products :
        if(i.category1 == "men") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               men.append(i)
    return render(request, "men.html", {'products' : men, 'login':login})

def women(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    women = []
    for i in products :
        if(i.category1 == "women") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               women.append(i)
    return render(request, "women.html", {'products' : women, 'login':login})

def All_Bottom(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    bottom = []
    for i in products :
        if(i.category2 == "bottom") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               bottom.append(i)
    return render(request, 'All_Bottom.html', {'products' : bottom, 'login':login})

def All_Outer(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    outer = []
    for i in products :
        if(i.category2 == "outer") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               outer.append(i)
    return render(request, 'All_Outer.html', {'products' : outer, 'login':login})

def All_Product(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    product = []
    for i in products :
        preplace=i.price.replace(",","")
        preplace=preplace.replace("원","")
        if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
           product.append(i)
    return render(request, 'All_Product.html', {'products' : product, 'login':login})

def All_Top(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    top = []
    for i in products :
        if(i.category2 == "top") :
            preplace=i.price.replace(",","")
            preplace=preplace.replace("원","")
            if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
               top.append(i)
    return render(request, 'All_Top.html', {'products' : top, 'login':login})

def M_Bottom(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    M_bottom = []
    for i in products :
        if(i.category1 == "men") :
            if(i.category2 == "bottom") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   M_bottom.append(i)

    return render(request, 'M_Bottom.html', {'products' : M_bottom, 'login':login})

def M_Outer(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    M_outer = []
    for i in products :
        if(i.category1 == "men") :
            if(i.category2 == "outer") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   M_outer.append(i)

    return render(request, 'M_Outer.html', {'products' : M_outer, 'login':login})

def M_Top(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    M_top = []
    for i in products :
        if(i.category1 == "men") :
            if(i.category2 == "top") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   M_top.append(i)

    return render(request, 'M_Top.html', {'products' : M_top, 'login':login})

# 상품의 고유번호 id
def Buy(request, id):
    product = Product.objects.get(pk=id)
    login = Check_user()

    return render(request, 'Buy.html', {'product' : product, 'login':login})

def W_Bottom(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    W_bottom = []
    for i in products :
        if(i.category1 == "women") :
            if(i.category2 == "bottom") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   W_bottom.append(i)

    return render(request, 'W_Bottom.html', {'products' : W_bottom, 'login':login})

def W_Outer(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    W_outer = []
    for i in products :
        if(i.category1 == "women") :
            if(i.category2 == "outer") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   W_outer.append(i)

    return render(request, 'W_Outer.html', {'products' : W_outer, 'login':login})

def W_Top(request):
    products = Product.objects.all()
    login = Check_user()
    price1 = request.GET.get('price1','')
    price2 = request.GET.get('price2','')

    if(price1==''):
        price1='0'
    if(price2==''):
        price2='1000000'

    W_top = []
    for i in products :
        if(i.category1 == "women") :
            if(i.category2 == "top") :
                preplace=i.price.replace(",","")
                preplace=preplace.replace("원","")
                if (int(price1) < int(preplace)) and (int(preplace) < int(price2)):
                   W_top.append(i)

    return render(request, 'W_Top.html', {'products' : W_top, 'login':login})

def Buy2(request, id):
    product = Product.objects.get(pk=id)
    buy_num = request.GET.get("buy_num")
    login = Check_user()

    if login == 0 :
        error = int(4)
        return render(request, 'Buy.html', {'product' : product, 'status' : error, 'login':login})

    if product.item_num <= 0 :
        error = int(2)
        return render(request, 'Buy.html', {'product' : product, 'status' : error, 'login':login})
    if (product.item_num - int(buy_num)) < 0 :
        error = int(1)
        return render(request, 'Buy.html', {'product' : product, 'status' : error, 'login':login})
    if int(buy_num) < 0 :
        error = int(3)
        return render(request, 'Buy.html', {'product' : product, 'status' : error, 'login':login})
    product.item_num = product.item_num - int(buy_num)
    product.save()

    preplace=product.price.replace(",","")
    preplace=preplace.replace("원","")
    price = int(buy_num) * int(preplace)
    return render(request, 'Buy2.html', {'product' : product, 'login':login, 'buy_num':buy_num, 'price':price})

def search(request):
    products = Product.objects.all()
    b = request.GET.get('b','')
    login = Check_user()

    search = []
    for i in products :
        if b == i.brand :
            search.append(i)
        elif b == i.category2:
            search.append(i)
        elif b == i.category3:
            search.append(i)

    return render(request, 'search.html', { 'products': search, 'login':login})

def Check_user():
    user = User.objects.all()
    for item in user :
        if item.status == 1 :
            return 1 
    return 0
