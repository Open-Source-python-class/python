from django.db import models

# Create your models here.
class Product(models.Model):
    price = models.CharField(max_length=200)
    brand = models.CharField(max_length=200)
    description = models.TextField(max_length=200)
    imageURL = models.URLField(max_length=200)
    item_num = models.IntegerField(default = 0)
    category = models.CharField(max_length=200)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) :
        return self.brand