import requests
import urllib.request
from bs4 import BeautifulSoup
import json
import os
import re
## Python이 실행될 때 DJANGO_SETTINGS_MODULE이라는 환경 변수에 현재 프로젝트의 settings.py파일 경로를 등록합니다.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "Main.settings")
## 이제 장고를 가져와 장고 프로젝트를 사용할 수 있도록 환경을 만듭니다.
import django
django.setup()
import random

from products.models import Product

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def parse_crawl():
    r = requests.get('https://store.musinsa.com/app/contents/bestranking')

    html = r.content
    soup = BeautifulSoup(html, 'html.parser')

    title_html = soup.select('.li_inner')

    data = {}

    for title in title_html:
        data[title.text] = title.get('.item_title')

    return data





## 이 명령어는 이 파일이 import가 아닌 python에서 직접 실행할 경우에만 아래 코드가 동작하도록 합니다.
if __name__=='__main__':
    data_dict = parse_crawl()
    for i in data_dict :
        Product(brand=i).save()