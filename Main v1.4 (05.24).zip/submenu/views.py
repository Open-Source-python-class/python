from django.shortcuts import render

# Create your views here.

def man(request) :
    return render(request, 'man.html')


def woman(request) :
    return render(request, 'woman.html')