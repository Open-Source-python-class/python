from django.shortcuts import render

# Create your views here.
def main(request) :
    return render(request, 'main.html')
    # 마! main.html을 보여주겠다.

def signup(request) :
    return render(request, 'signup.html')
    # 마! signup.html을 보여주겠다.