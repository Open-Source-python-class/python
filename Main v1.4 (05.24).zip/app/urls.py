from django.urls import path
from . import views
#현재 경로를 나타내는 .

urlpatterns = [
    path('signup/', views.signup, name="signup"),
]