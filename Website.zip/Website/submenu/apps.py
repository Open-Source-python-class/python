from django.apps import AppConfig


class SubmenuConfig(AppConfig):
    name = 'submenu'
