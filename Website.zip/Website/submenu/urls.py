from django.urls import path
from . import views

urlpatterns = [
    path('man/', views.man, name="man"),
    path('woman/', views.woman, name="woman"),
]