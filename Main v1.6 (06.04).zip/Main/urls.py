"""Main URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from websites import urls, views
from django.conf import settings
from django.conf.urls.static import static
from users import urls as users_urls

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.main, name='main'),
    path('users/', include(users_urls)),
    path('men/', views.men, name='men'),
    path('women/', views.women, name='women'),
    path('All_Outer/', views.All_Outer, name='All_Outer'),
    path('All_Bottom/', views.All_Bottom, name='All_Bottom'),
    path('All_Top/', views.All_Top, name='All_Top'),
    path('All_Product/', views.All_Product, name='All_Product'),
    path('M_Bottom/', views.M_Bottom, name='M_Bottom'),
    path('M_Outer/', views.M_Outer, name='M_Outer'),
    path('M_Top/', views.M_Top, name='M_Top'),
    path('W_Bottom/', views.W_Bottom, name='W_Bottom'),
    path('W_Outer/', views.W_Outer, name='W_Outer'),
    path('W_Top/', views.W_Top, name='W_Top'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
