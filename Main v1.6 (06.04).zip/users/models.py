from django.db import models

class User(models.Model):
    name = models.CharField(max_length=200)
    pw = models.CharField(max_length=200)
    User_id = models.CharField(max_length=200)
    status = models.IntegerField(default = 0)
    identification_number = models.IntegerField(default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) :
        return self.name

class User_Info(models.Model):
    delivery_location = models.CharField(max_length=200)    # 배송지
    name = models.CharField(max_length=200)                 # 회원 이름
    recipient = models.CharField(max_length=200)            # 수령인
    phone_number = models.CharField(max_length=200)         # 핸드폰 번호
    payment_method = models.CharField(max_length=100)       # 결제수단
    bank_name = models.CharField(max_length=200)            # 은행이름
    bank_owner = models.CharField(max_length=200)           # 은행 소유주
    card_number = models.CharField(max_length=200)          # 카드번호
    product_name = models.CharField(max_length=200)         # 상품 이름

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) :
        return self.name
