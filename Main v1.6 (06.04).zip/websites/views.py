from django.shortcuts import render
from products.models import Product
# Create your views here.

def main(request):
    return render(request, "main.html")

def top(request):
    return render(request, "top.html")

def men(request):
    products = Product.objects.all()

    return render(request, "men.html", {'products' : products})

def women(request):
    return render(request, "women.html")

def bottom(request):
    return render(request, "bottom.html")

def outer(request):
    return render(request, "outer.html")

def All_Bottom(request):
    return render(request, 'All_Bottom.html')

def All_Outer(request):
    return render(request, 'All_Outer.html')

def All_Product(request):
    return render(request, 'All_Product.html')

def All_Top(request):
    return render(request, 'All_Top.html')

def M_Bottom(request):
    return render(request, 'M_Bottom.html')

def M_Outer(request):
    return render(request, 'M_Outer.html')

def M_Top(request):
    return render(request, 'M_Top.html')

def W_Bottom(request):
    return render(request, 'W_Bottom.html')

def W_Outer(request):
    return render(request, 'W_Outer.html')

def W_Top(request):
    return render(request, 'W_Top.html')